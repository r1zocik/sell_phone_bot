import asyncio
from aiogram import Bot, Dispatcher
from config import BOT_TOKEN
from database import create_db
from handlers import start, sell, ads

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

async def main():
    create_db()

    dp.include_router(start.router)
    dp.include_router(sell.router)
    dp.include_router(ads.router)

    print("✅ Bot ishga tushdi")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
