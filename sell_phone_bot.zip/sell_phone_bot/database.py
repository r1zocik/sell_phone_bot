import sqlite3

def create_db():
    conn = sqlite3.connect("phones.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS phones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            brand TEXT,
            model TEXT,
            color TEXT,
            price TEXT,
            phone_number TEXT
        )
    """)
    conn.commit()
    conn.close()

def add_phone(user_id, brand, model, color, price, phone_number):
    conn = sqlite3.connect("phones.db")
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO phones (user_id, brand, model, color, price, phone_number)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (user_id, brand, model, color, price, phone_number))
    conn.commit()
    conn.close()

def get_user_phones(user_id):
    conn = sqlite3.connect("phones.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT brand, model, color, price, phone_number FROM phones
        WHERE user_id = ?
    """, (user_id,))
    rows = cur.fetchall()
    conn.close()
    return rows
