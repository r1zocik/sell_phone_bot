from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

def main_menu():
    kb = [
        [KeyboardButton(text="📱 Telefon sotish")],
        [KeyboardButton(text="📋 Mening elonlarim")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)



def brand_kb():
    kb = [
        [KeyboardButton(text="iPhone"), KeyboardButton(text="Redmi"), KeyboardButton(text="Samsung")],
        [KeyboardButton(text="⬅️ Orqaga")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

def color_kb():
    kb = [
        [KeyboardButton(text="⚫ Qora"), KeyboardButton(text="⚪ Oq"), KeyboardButton(text="🔵 Ko'k")],
        [KeyboardButton(text="⬅️ Orqaga")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

def contact_kb():
    kb = [
        [KeyboardButton(text="📞 Kontakt raqamingizni yuboring", request_contact=True)],
        [KeyboardButton(text="⬅️ Orqaga")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

def tasdiqlash_kb():
    kb = [
        [KeyboardButton(text="✅ Tasdiqlash"), KeyboardButton(text="❌ Bekor qilish")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)