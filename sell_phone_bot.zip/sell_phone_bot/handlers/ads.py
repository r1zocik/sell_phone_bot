from aiogram import Router, types, F
from database import get_user_phones
from keyboards.default import main_menu

router = Router()

@router.message(F.text == "📋 Mening elonlarim")
async def show_my_ads(message: types.Message):
    ads = get_user_phones(message.from_user.id)
    if not ads:
        return await message.answer("❌ Elon xali yoq.", reply_markup=main_menu())

    text = "📋 *Sizning elonlaringiz:*\n\n"
    for ad in ads:
        brand, model, color, price, phone_number = ad
        text += (
            f"📱 {brand} {model}\n"
            f"🎨 Rangi: {color}\n"
            f"💰 {price} som\n"
            f"📞 {phone_number}\n\n"
        )

    await message.answer(text, parse_mode="Markdown", reply_markup=main_menu())
