import os
from aiogram import Router, types, F, Bot
from aiogram.types import FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from keyboards.default import brand_kb, color_kb, contact_kb, main_menu
from database import add_phone
from config import CHANNEL_ID

router = Router()
user_data = {}


# --- Inline кнопки подтверждения / отмены ---
def tasdiqlash_kb_inline():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data="confirm"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="cancel")
        ]
    ])


# --- Начало процесса: выбор телефона ---
@router.message(F.text == "📱 Telefon sotish")
async def start_sell(message: types.Message):
    user_data[message.from_user.id] = {}
    await message.answer("📸 Rasm yuboring:")


# --- Получение фото ---
@router.message(F.photo)
async def handle_photo(message: types.Message, bot: Bot):
    user_id = message.from_user.id

    if user_id not in user_data:
        user_data[user_id] = {}

    os.makedirs("photos", exist_ok=True)
    photo = message.photo[-1]
    file_path = f"photos/{user_id}_{photo.file_id}.jpg"

    # ✅ Скачать фото
    file = await bot.get_file(photo.file_id)
    await bot.download_file(file.file_path, file_path)

    user_data[user_id]["photo_path"] = file_path

    await message.answer("✅ Rasm qabul qilindi!")
    await message.answer("Brendni tanlang:", reply_markup=brand_kb())


# --- Выбор бренда ---
@router.message(F.text.in_(["iPhone", "Redmi", "Samsung"]))
async def choose_model(message: types.Message):
    user_id = message.from_user.id
    user_data[user_id]["brand"] = message.text

    models = {
        "iPhone": ["iPhone 15 Pro", "iPhone 14", "iPhone 13"],
        "Redmi": ["Redmi Note 13", "Redmi 12", "Redmi 10"],
        "Samsung": ["S24 Ultra", "A55", "A35"]
    }

    kb = [[types.KeyboardButton(text=model)] for model in models[message.text]]
    kb.append([types.KeyboardButton(text="⬅️ Orqaga")])
    await message.answer("📱 Modelni tanlang:", reply_markup=types.ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True))


# --- Последовательный ввод модели, цвета, цены ---
@router.message(lambda msg: msg.from_user and msg.from_user.id in user_data and msg.text)
async def process_steps(message: types.Message):
    user_id = message.from_user.id
    data = user_data[user_id]

    if "model" not in data and "brand" in data:
        data["model"] = message.text
        return await message.answer("🎨 Rangini tanlang:", reply_markup=color_kb())

    if "color" not in data and "model" in data:
        data["color"] = message.text
        await message.answer("💰 Telefon narxini kiriting (so'mda):", reply_markup=types.ReplyKeyboardRemove())
        return

    if "price" not in data and "color" in data:
        if not message.text.isdigit():
            return await message.answer("❗ Narxni raqam bilan kiriting, masalan 4500000:")
        data["price"] = message.text
        await message.answer("📞 Kontakt raqamingizni yuboring:", reply_markup=contact_kb())
        return


# --- Получение контакта и показ предпросмотра ---
@router.message(F.contact)
async def save_contact(message: types.Message):
    user_id = message.from_user.id
    data = user_data.get(user_id)
    if not data:
        return await message.answer("Iltimos, /start bilan boshlang")

    data["phone_number"] = message.contact.phone_number

    ad_text = (
        f"📱 *Sotish haqida e'lon*\n\n"
        f"🔹 Brend: {data['brand']}\n"
        f"🔹 Model: {data['model']}\n"
        f"🔹 Rang: {data['color']}\n"
        f"💰 Narx: {data['price']} so'm\n"
        f"📞 Kontakt: {data['phone_number']}"
    )

    photo_path = data.get("photo_path")

    if photo_path:
        photo = FSInputFile(photo_path)
        await message.answer_photo(
            photo=photo,
            caption=ad_text,
            parse_mode="Markdown",
            reply_markup=tasdiqlash_kb_inline()
        )
    else:
        await message.answer(ad_text, parse_mode="Markdown", reply_markup=tasdiqlash_kb_inline())


# --- Подтверждение публикации (Inline кнопка) ---
@router.callback_query(F.data == "confirm")
async def confirm_post(cb: types.CallbackQuery, bot: Bot):
    user_id = cb.from_user.id
    data = user_data.get(user_id)
    if not data:
        await cb.answer("Hech qanday e'lon topilmadi.")
        return

    ad_text = (
        f"📱 *Sotish haqida e'lon*\n\n"
        f"🔹 Brend: {data['brand']}\n"
        f"🔹 Model: {data['model']}\n"
        f"🔹 Rang: {data['color']}\n"
        f"💰 Narx: {data['price']} so'm\n"
        f"📞 Kontakt: {data['phone_number']}"
    )

    photo_path = data.get("photo_path")

    # Отправка в канал
    if photo_path and os.path.exists(photo_path):
        photo = FSInputFile(photo_path)
        await bot.send_photo(CHANNEL_ID, photo=photo, caption=ad_text, parse_mode="Markdown")
        os.remove(photo_path)
    else:
        await bot.send_message(CHANNEL_ID, ad_text, parse_mode="Markdown")

    await cb.message.answer("✅ E'loningiz kanalga joylandi!", reply_markup=main_menu())
    user_data.pop(user_id, None)
    await cb.answer("Joylandi ✅")


# --- Отмена публикации (Inline кнопка) ---
@router.callback_query(F.data == "cancel")
async def cancel_post(cb: types.CallbackQuery):
    user_id = cb.from_user.id
    data = user_data.get(user_id)

    if data and "photo_path" in data:
        photo_path = data["photo_path"]
        if os.path.exists(photo_path):
            os.remove(photo_path)

    user_data.pop(user_id, None)
    await cb.message.answer("❌ E'lon bekor qilindi.", reply_markup=main_menu())
    await cb.message.answer("📱 Yangi e'lon boshlash uchun '📱 Telefon sotish' tugmasini bosing.")
    await cb.answer("Bekor qilindi ❌")
