from aiogram import Router, types
from aiogram.filters import Command
from keyboards.default import main_menu

router = Router()

@router.message(Command("start"))
async def start(message: types.Message):
    await message.answer("👋 Botga xush kelibsiz! ", reply_markup=main_menu())
